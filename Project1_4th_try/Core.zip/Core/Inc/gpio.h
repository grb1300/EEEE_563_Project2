/*
 * gpio.h
 *
 *  Created on: Nov 4, 2021
 *      Author: Mitesh Parikh
 */

#ifndef INC_GPIO_H_
#define INC_GPIO_H_

#include "main.h"
#include "stm32l4xx_hal_gpio.h"

void GPIO_Init(void);

#endif /* INC_GPIO_H_ */
