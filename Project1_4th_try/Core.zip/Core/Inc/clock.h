/*
 * clock.h
 *
 *  Created on: Feb 3, 2025
 *      Author: manali
 */

#ifndef INC_CLOCK_H_
#define INC_CLOCK_H_

void clock_init(void);


#endif /* INC_CLOCK_H_ */
