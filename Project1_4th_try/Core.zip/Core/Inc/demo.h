// SWEN 340 Demo code header file
// Larry Kiser copyright 2021



/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __DEMO_H
#define __DEMO_H

#include "main.h"
int printf (const char *format, ...) ;
void init_systick( void ) ;
void run_demo( void ) ;

#endif /* __DEMO_H */
